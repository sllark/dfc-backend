import { Router } from "express";
import { serviceController } from "../controllers/serviceController";
import AuthMiddleware from "../middlewares/authMiddleware";
import { upload } from "../middlewares/uploadMiddleware";

const router = Router();

router.post("/", AuthMiddleware.authenticate, upload.single("bannerImage"), serviceController.create);
router.get("/", serviceController.getAll);
router.get("/:id", serviceController.getById);
router.put("/:id", AuthMiddleware.authenticate, upload.single("bannerImage"), serviceController.update);
router.delete("/:id", AuthMiddleware.authenticate, serviceController.delete);

export default router;
