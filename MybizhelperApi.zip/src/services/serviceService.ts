import { PrismaClient, Prisma } from "../generated/prisma";

interface GetAllParams {
    page: number;
    perPage: number;
    search: string | undefined;
    status: string | undefined;
}

const prisma = new PrismaClient();

export const serviceService = {
    async create(data: Prisma.ServiceUncheckedCreateInput) {
        return prisma.service.create({ data });
    },

    async getAll({ page, perPage, search, status }: GetAllParams) {
        const skip = (page - 1) * perPage;

        const andConditions: Prisma.ServiceWhereInput[] = [];

        if (search) {
            andConditions.push({
                OR: [
                    { name: { contains: search, mode: "insensitive" } },
                    { slug: { contains: search, mode: "insensitive" } },
                    { accountNo: { contains: search, mode: "insensitive" } },
                ],
            });
        }

        if (status === "true") {
            andConditions.push({ status: true });
        } else if (status === "false") {
            andConditions.push({ status: false });
        }

        const where: Prisma.ServiceWhereInput = {
            isDelete: false,
            ...(andConditions.length > 0 ? { AND: andConditions } : {}),
        };

        const [data, total] = await Promise.all([
            prisma.service.findMany({
                where,
                orderBy: { createdAt: "desc" },
                skip,
                take: perPage,
            }),
            prisma.service.count({ where }),
        ]);

        return { data, total };
    },

    async getById(id: number) {
        return prisma.service.findUnique({
            where: { id },
        });
    },

    async update(id: number, data: Prisma.ServiceUncheckedUpdateInput) {
        return prisma.service.update({
            where: { id },
            data,
        });
    },

    async softDelete(id: number, updatedBy: number) {
        return prisma.service.update({
            where: { id },
            data: { isDelete: true, updatedBy },
        });
    },
};
