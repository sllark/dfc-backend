import dotenv from 'dotenv';
import cors from 'cors';
import express from 'express';
import type { Request, Response } from 'express';
import AuthRoutes from './routes/authRoute'
import serviceRoutes from "./routes/serviceRoute";
import path from 'path';

dotenv.config();

const app = express();

app.use(cors({
  origin: '*'
  // origin: ['http://localhost:3000'],
}));

app.use(express.json());
// Serve uploaded images
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));
app.use('/api', AuthRoutes);
app.use("/api/services", serviceRoutes);
const port = process.env.PORT || 3000;
const host = process.env.HOST || 'localhost';

app.get('/', (req: Request, res: Response) => {
  res.send('SD Coders API is running!');
});

app.listen(port, () => {
  console.log(`✅ Server is running at http://${host}:${port}`);
  console.log('Press Ctrl+C to stop the server.');
});
