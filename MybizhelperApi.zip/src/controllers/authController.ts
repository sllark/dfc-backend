import AuthService from '../services/authService';
import type { Request, Response } from 'express';
import { AuthenticatedRequest } from '../utils/types';

class AuthController {
    // User registration
    static signup = async (req: Request, res: Response) => {
        try {
            const { username, email, password, phone } = req.body;

            const existingUser = await AuthService.findUserByEmail(email);
            if (existingUser) {
                return res.status(400).json({ message: 'User already exists' });
            }

            const user = await AuthService.registerUser(username, email, password, phone);

            return res.status(201).json({ message: 'User registered successfully', user });
        } catch (error: any) {
            console.error('Signup Error:', error);
            return res.status(400).json({ message: 'Registration failed', error: error.message });
        }
    };

    // User login
    static login = async (req: Request, res: Response) => {
        try {
            const { email, password } = req.body;

            const token = await AuthService.loginUser(email, password);

            return res.status(200).json({ token });
        } catch (error: any) {
            console.error('Login Error:', error);
            return res.status(400).json({ message: 'Login failed', error: error.message });
        }
    };

    // Get user by ID (authenticated route)
    static getUserById = async (req: AuthenticatedRequest, res: Response) => {
        try {
            if (!req.user) {
                return res.status(401).json({ message: "Unauthorized" });
            }

            const userId = parseInt(req.params.id ?? "", 10);
            if (isNaN(userId)) {
                return res.status(400).json({ message: "Invalid user ID" });
            }

            // ✅ Restrict access
            if (req.user.role !== "ADMIN" && req.user.userId !== userId) {
                return res.status(403).json({ message: "Forbidden: Access denied" });
            }

            const foundUser = await AuthService.findUserById(userId);

            if (!foundUser) {
                return res.status(404).json({ message: "User not found" });
            }

            return res.status(200).json(foundUser);
        } catch (error: any) {
            console.error("GetUserById Error:", error);
            return res.status(500).json({ message: "Error retrieving user", error: error.message });
        }
    };

    static getAllUsers = async (req: AuthenticatedRequest, res: Response) => {
        try {
            if (!req.user || req.user.role !== "ADMIN") {
                return res.status(403).json({ message: "Forbidden: Admins only" });
            }

            // Read query parameters
            const { email, phone, role } = req.query;

            const users = await AuthService.getAllUsers({
                email: email as string,
                phone: phone as string,
                role: role as string,
            });

            return res.status(200).json(users);
        } catch (error: any) {
            console.error("GetAllUsers Error:", error);
            return res.status(500).json({ message: "Error retrieving users", error: error.message });
        }
    };

    static updateUser = async (req: Request, res: Response) => {
        const authReq = req as AuthenticatedRequest; // ✅ cast here

        try {
            if (!authReq.user) return res.status(401).json({ message: "Unauthorized" });

            const userIdStr = authReq.params.id;
            if (!userIdStr) return res.status(400).json({ message: "User ID is required" });

            const userId = parseInt(userIdStr, 10);
            if (isNaN(userId)) return res.status(400).json({ message: "Invalid user ID" });

            // only admin or the same user
            if (authReq.user.role !== "ADMIN" && authReq.user.userId !== userId) {
                return res.status(403).json({ message: "Forbidden: Access denied" });
            }

            const { username, phone, password } = authReq.body;

            const updateData: {
                username?: string;
                phone?: string;
                password?: string;
                profileImage?: string;
            } = {};

            if (username) updateData.username = username;
            if (phone) updateData.phone = phone;
            if (password) updateData.password = password;
            if (authReq.file) updateData.profileImage = `/uploads/${authReq.file.filename}`;

            const updatedUser = await AuthService.updateUser(userId, updateData);

            return res.status(200).json({ message: "User updated successfully", user: updatedUser });
        } catch (error: any) {
            console.error("UpdateUser Error:", error);
            return res.status(500).json({ message: "Error updating user", error: error.message });
        }
    };


    static logout = async (req: AuthenticatedRequest, res: Response) => {
        try {
            // On client: remove token from storage
            return res.status(200).json({ message: "Logged out successfully" });
        } catch (err: any) {
            return res.status(500).json({ message: "Logout failed", error: err.message });
        }
    };

    static async forgotPassword(req: Request, res: Response) {
        try {
            const { email } = req.body;
            const result = await AuthService.sendPasswordResetOTP(email);
            res.status(200).json(result);
        } catch (e: any) {
            res.status(400).json({ message: e.message || "Failed to send OTP" });
        }
    }

    static async verifyOTP(req: Request, res: Response) {
        try {
            const { email, otp } = req.body;
            const result = await AuthService.verifyOTP(email, otp);
            res.status(200).json(result);
        } catch (err: any) {
            res.status(400).json({ error: err.message });
        }
    }

    static async resetPassword(req: Request, res: Response) {
        try {
            const { email, otp, newPassword } = req.body;
            const result = await AuthService.resetPassword(email, otp, newPassword);
            res.status(200).json(result);
        } catch (err: any) {
            res.status(400).json({ error: err.message });
        }
    }

}

export default AuthController;
